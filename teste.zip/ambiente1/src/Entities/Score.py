
import pygame

class Score:
    def __init__(self):
        self.text_font()
        self.score_surface()
        self.score_rectangle()



    
    def text_font(self):
        self.text = pygame.font.Font('font/Pixeltype.ttf', 60)#parânmetros usados: tipo da fonte e tamanho dela

    def score_surface(self):
        self.score_surf = self.text.render('Score', False, (64,64,64)) #text, AA, color(Antialisgn) como estou trabalhando com pixel art, será false


    def get_surface(self):
        return self.score_surf
    


    
    def score_rectangle(self):
                self.score_rect = self.score_surf.get_rect(center = (400, 50) )

                

    #def update_position(self, p):
          #self.player_rect.left += p

     #     self.teste = print(self.player_rect)

      #    return self.teste