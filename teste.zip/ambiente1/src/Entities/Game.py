
from Entities.Player import *
from Entities.Enemie import *
from Entities.Score import *
import pygame
from sys import exit  # finaliza qualquer código quando chamado

class Game:
    def __init__(self):
        pygame.init()
        self.game_state()
        self.screenWindow()
        self.test_surface()
        self.clock()
        self.player = Player()
        self.enemie = Enemie()
        self.score = Score()
        


    
    def game_state(self):
        self.game_active = True

    def screenWindow(self):
        pygame.display.set_caption('JumpBro')
        self.screen = pygame.display.set_mode((800, 400))

    def test_surface(self):
        self.sky_surface = pygame.image.load('graphics/NightSky3.png').convert()
        self.ground_surface = pygame.image.load('graphics/ground.png').convert()

    def clock(self):
        self.clocktime = pygame.time.Clock()

    def draw(self):
        self.screen.blit(self.sky_surface, (0, 0))
        self.screen.blit(self.ground_surface, (0, 300))
        pygame.draw.rect(self.screen, '#c0e8ec', self.score.score_rect)
        pygame.draw.rect(self.screen, '#c0e8ec', self.score.score_rect, 10)
        self.screen.blit(self.score.get_surface(), self.score.score_rect)

        self.enemie.update_position()
        self.screen.blit(self.enemie.get_surface(), self.enemie.enemie_rect)
        self.screen.blit(self.player.get_surface(), self.player.player_rect)


        self.font = pygame.font.Font(None, 74)  # Fonte padrão e tamanho 74
        self.game_over_text = self.font.render('GAME OVER', True, (255, 255, 255))  




    def colisions(self):#com esse método eu vou conseguir aplicar a lógica de derrota
        #rect1.collidepoint((x,y)) ele verifica se um determinado retangulo colidiu com determinada posição
        if self.enemie.enemie_rect.colliderect(self.player.player_rect) == 1:#me entrega 0 ou 1 como resultado(true or false)
            self.game_active = False
            print('colision')
        #self.mouse_pos = pygame.mouse.get_pos()
        #if self.player.player_rect.collidepoint((self.mouse_pos)):
         #   print(pygame.mouse.get_pressed())


    def loop_event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                self.player.mouse_jump(event.pos)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.player.player_jump()

    def run(self):
        while True:
            self.current_time = pygame.time.get_ticks()  # pegar o tempo em milissegundos
            self.loop_event()

            self.player.player_gravity(1)
            if self.game_active == True:
                self.draw()
            
                self.colisions()
            else: 
                self.screen.fill('Black')
                self.screen.blit(self.game_over_text, (self.screen.get_width() // 2 - self.game_over_text.get_width() // 2,
                                                      self.screen.get_height() // 2 - self.game_over_text.get_height() // 2))

            pygame.display.update()
            self.clocktime.tick(60)  # isso vai obrigar o while a rodar 60 vezes por segundo pra fixar a taxa de quadros







