from Game import * 

if __name__ == '__main__': 
    game = Game()
    game.run()