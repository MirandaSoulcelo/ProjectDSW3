from Player import *
from Enemie import *
import pygame
from sys import exit #finaliza qualquer code  quando chamado

class Game:
    def __init__(self):
        #pygame.init() é quem inicia 
        pygame.init()

        self.screenWindow()
        self.text_font()
        self.test_surface()
        self.clock()
        self.player = Player()
        self.enemie = Enemie()
        
   






    def screenWindow(self):
        pygame.display.set_caption('JumpBro')
        self.screen = pygame.display.set_mode((800, 400))




    def text_font(self):
        self.test_font = pygame.font.Font('font/Pixeltype.ttf', 50)#parânmetros usados: tipo da fonte e tamanho dela




    def test_surface(self):

        self.sky_surface = pygame.image.load('graphics/NightSky3.png').convert()
        self.ground_surface = pygame.image.load('graphics/ground.png').convert()
        self.text_surface = self.test_font.render('Score', False, 'Black') #text, AA, color(Antialisgn) como estou trabalhando com pixel art, será false
     
   
  
       

    def clock(self):
        #clockobject
        self.clocktime = pygame.time.Clock()


    def draw(self):
         
        self.screen.blit(self.sky_surface, (0, 0))
        self.screen.blit(self.ground_surface, (0, 300))
        self.screen.blit(self.text_surface, (300, 50))


        
   
        self.screen.blit(self.enemie.get_surface(), self.enemie.enemie_rect)
        self.enemie.update_position()
        self.screen.blit(self.player.get_surface(), self.player.player_rect)
        

    def run(self):
        while True:
            #preciso desse pygame.QUIT para eu poder Fechar a janela!!
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
           
            self.draw()
            #event logic
            pygame.display.update()
            self.clocktime.tick(60)#isso vai obrigar o while a rodar 60 vezes por segundo pra fixar a taxa de quadros
    
    
        