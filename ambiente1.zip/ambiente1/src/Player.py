

import pygame

class Player:
    def __init__(self):

        self.player_surface()
        self.player_rectangle()


    def player_surface(self):
        self.player_surf = pygame.image.load('graphics/Runningsora2.png').convert_alpha()

    def get_surface(self):
        return self.player_surf
    
    def player_rectangle(self):
                self.player_rect = self.player_surf.get_rect(midbottom = (50, 300) )

                return self.player_rect

    def update_position(self, p):
          #self.player_rect.left += p

          self.teste = print(self.player_rect)

          return self.teste